library(lavaan) 
library(tidyverse)
library(lubridate)


#<############################################################################>
#
# LOAD DATA ####
#
#<############################################################################>

data <- read_csv2("./data.csv")



#<############################################################################>
#
# RECODES ####
#
#<############################################################################>

# creating labels for gender
data <- data %>% 
  mutate(gnd = as.factor(gnd))



#Creating a numerical gender variable (for the correlation matrix later)
data <- data %>% 
  mutate(gnd_num = case_when(gnd == "male" ~ 0,
                             gnd == "female" ~ 1)) 



#<############################################################################>
#
# GENERATION OF COMPOSITES----
#
#<############################################################################>

data <- data %>% 
  mutate(eeaX.t1 = rowMeans(select(.,epbhv01.t1,epbhv02.t1,epbhv03.t1,epbhv04.t1,
                                   epbhv05.t1,epbhv06.t1,epbhv07.t1,epbhv08.t1),na.rm=TRUE)) %>% 
  mutate(csefX.t1 = rowMeans(select(.,csef02.t1, csef03.t1),na.rm=TRUE)) %>% 
  mutate(lskX.t1 = rowMeans(select(., srp01.t1, srp02.t1, srp03.t1, srp04.t1, srp05.t1), na.rm=TRUE)) %>% 
  mutate(entalX.t1 = rowMeans(select(.,ental01.t1,ental02.t1), na.rm=TRUE)) %>% 
  mutate(eeaX.t2 = rowMeans(select(.,epbhv01.t2,epbhv02.t2,epbhv03.t2,epbhv04.t2,
                                   epbhv05.t2,epbhv06.t2,epbhv07.t2,epbhv08.t2),na.rm=TRUE)) %>% 
  mutate(csefX.t2 = rowMeans(select(.,csef02.t2, csef03.t2),na.rm=TRUE)) %>% 
  mutate(lskX.t2 = rowMeans(select(., srp01.t2, srp02.t2, srp03.t2, srp04.t2, srp05.t2), na.rm=TRUE)) %>% 
  mutate(entalX.t2 = rowMeans(select(.,ental01.t2,ental02.t2), na.rm=TRUE)) 
  




