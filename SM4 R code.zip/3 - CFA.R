library(lavaan)
library(MIIVsem)


#<############################################################################>
#                                                                            
# Generating the SWAIN function ####
#                                                                            
#<############################################################################>


'Run the complete block. This creates teh swain funcition in which later model
statistics are fed'



swain <- function(N, p, d, TML, TMLi, conf.level=0.90) {
  # N: sample size
  # p: number of observed variables
  # d: number of degrees of freedom for model M_j
  # TML: chi-square likelihood-ratio test statistic for model M_j,
  #      i.e., T_{ML_j}
  # TMLi: chi-square test statistic for the independence model M_i, T_{ML_i}
  # conf.level: confidence level for interval estimation (default 0.90)
  
  n <- N - 1
  t <- p*(p+1)/2 - d                       # number of parameters
  pTML <- 1 - pchisq(TML,d)                # p-value of T_ML_j
  q <- (sqrt(1+8*t)-1)/2                   # (11) 
  num <- p*(2*p^2+3*p-1)-q*(2*q^2+3*q-1)   # numerator in (10)
  den <- 12*d*(N-1)                        # denominator in (10)
  s <- 1 - num/den                         # Swain's correction factor s (10)
  TMLs <- s*TML                            # Swain-corrected test statistic (12)
  pTMLs <- 1 - pchisq(TMLs,d)              # p-value of T_MLs
  di <- p*(p-1)/2                          # degrees of freedom of model M_i
  RMSEA <- sqrt(max((TML-d)/(n*d),0))      # Root Mean Square Error of
  # Approximation 
  RMSEAs <- sqrt(max((TMLs-d)/(n*d),0))    # Swain's estimate RMSEAs
  
  # Calculating confidence limits for RMSEA and RMSEAs using
  # function uniroot for one-dimensional root finding
  lower.tail <- (1 - conf.level)/2
  upper.tail <- 1 - lower.tail
  interval <- c(0, 500000)
  lower <- uniroot(function(x)
    ifelse(x > 0, pchisq(ncp=x,q=TML,df=d) - upper.tail, 1), interval)$root
  RMSEAl <- sqrt(max((lower)/(n*d),0))  
  upper <- uniroot(function(x)
    ifelse(x > 0, pchisq(ncp=x,q=TML,df=d) - lower.tail, 1), interval)$root
  RMSEAu <- sqrt(max((upper)/(n*d),0))
  lowers <- uniroot(function(x)
    ifelse(x > 0, pchisq(ncp=x,q=TMLs,df=d) - upper.tail, 1), interval)$root
  RMSEAsl <- sqrt(max((lowers)/(n*d),0))
  uppers <- uniroot(function(x)
    ifelse(x > 0, pchisq(ncp=x,q=TMLs,df=d) - lower.tail, 1), interval)$root
  RMSEAsu <- sqrt(max((uppers)/(n*d),0))
  
  L <-  0.05^2*n*d
  pclose <- 1-pchisq(ncp=L,q=TML,df=d)
  pcloses <- 1-pchisq(ncp=L,q=TMLs,df=d)
  Gamma1 <- p/(p+2*(TML-d)/n)              # Gamma_1 (Steiger) 
  Gamma1l <- p/(p+2*(upper)/n)
  Gamma1u <- p/(p+2*(lower)/n)
  Gamma1s <- p/(p+2*(TMLs-d)/n)            # Swain's estimate of Gamma_1   
  Gamma1sl <- p/(p+2*(uppers)/n)
  Gamma1su <- p/(p+2*(lowers)/n)
  TLI <- (TMLi/di - TML/d)/(TMLi/di - 1)   # Tucker-Lewis Index
  TLIs <- (TMLi/di - TMLs/d)/(TMLi/di -1)  
  tau <-  max(TML-d, 0)                  
  taus <-  max(TMLs-d, 0)                  # Swain's estimate TLIs   
  taui <-  max(TMLi-di, TML-d, 0)          
  CFI <- 1 - tau/taui                      # Comparative Fit Index (Bentler)
  CFIs <- 1 - taus/taui                    # Swain's estimate CFIs
  CIV2 <-  100*conf.level
  
  cat("\n  R function swain (Version 1.2)          -- Boomsma & Herzog (2013)", "\n")
  cat("\n  Equations and Monte-Carlo results of the corrections are available",
      "\n")
  cat("  in Herzog, Boomsma, & Reinecke (2007) and Herzog & Boomsma (2006);", 
      "\n")
  cat("  see the online documentation of the swain function.", "\n")
  cat("\nSample size, N =", N, "\n")                              
  cat("Number of observed variables, p =", p, "\n")
  cat("Number of degrees of freedom, d =", d, "\n")
  cat("Chi-square test statistic, TML = ", TML,", p-value: ", pTML, "\n",
      sep="")
  cat("Swain's correction factor:", s, "\n")
  cat("Swain-corrected chi-square test statistic: ", TMLs,", p-value: ", 
      pTMLs, "\n", sep="")
  cat("Chi-square test statistic of the independence model, TMLi =", TMLi, 
      "\n")
  cat("\nEstimate of the Root Mean Square Error of Approximation (RMSEA):",
      RMSEA, "\n")
  cat(CIV2, "% confidence interval for RMSEA: (", RMSEAl, ", ", RMSEAu,
      ")", "\n", sep="")
  cat("Test of close fit: H_0: RMSEA < .05, p-value:", pclose, "\n")
  cat("Swain-corrected RMSEA:", RMSEAs, "\n")
  cat("Swain-corrected ", CIV2, "% confidence interval for RMSEA: (", 
      RMSEAsl, ", ", RMSEAsu, ")", "\n", sep="")
  cat("Swain-corrected test of close fit: H_0: RMSEA < .05, p-value:",
      pcloses, "\n")
  cat("\nEstimate of Gamma_1:", Gamma1, "\n")
  cat(CIV2, "% confidence interval for Gamma_1: (", Gamma1l, ", ", Gamma1u, 
      ")", "\n", sep="")
  cat("Swain-corrected Gamma_1:", Gamma1s, "\n")
  cat("Swain-corrected ", CIV2, "% confidence interval for Gamma_1: (",
      Gamma1sl, ", ", Gamma1su, ")", "\n", sep="")
  cat("\nTucker-Lewis Index (TLI):", TLI,"\n")
  cat("Swain-corrected Tucker-Lewis Index:", TLIs,"\n")
  cat("Comparative Fit Index (CFI):", CFI,"\n")
  cat("Swain-corrected Comparative Fit Index:", CFIs,"\n","\n")
}                                                   # end of swain function




#<############################################################################>
#                                                                            
# CFA Models----
#                                                                            
#<############################################################################>



# Respecified CFA model (omitting the second CSEF indicator and the third alertness indicaotr)

cfa1 <- '
  CSEF_t1 =~ csef02.t1 + csef03.t1 
  CSEF_t2 =~ csef02.t2 + csef03.t2 
  LST_t1 =~ lskX.t1
  LST_t2 =~ lskX.t2
  EEA_t1 =~ eeaX.t1
  EEA_t2 =~ eeaX.t2
  ENTAL_t1 =~ ental02.t1 + ental01.t1  
  ENTAL_t2 =~ ental02.t2+ ental01.t2 
  
  # Banded error structure
  csef02.t1 ~~csef02.t2
  csef03.t1 ~~csef03.t2
  ental01.t1 ~~ental01.t2
  ental02.t1 ~~ental02.t2
 
#fixed errors
  eeaX.t1 ~~.201*eeaX.t1
  eeaX.t2 ~~.189*eeaX.t2
  lskX.t1 ~~.192*lskX.t1
  lskX.t2 ~~.23*lskX.t2
'

fit.cfa1 <- sem(cfa1, data = data, estimator="MLR", missing="FIML")

summary(fit.cfa1, fit.measures=TRUE, standardized=TRUE)

swain(276, 12, 26, 23.38, 1104.954)





# Invariance tests
cfa2 <- '
  CSEF_t1 =~ csef02.t1 + a*csef03.t1 
  CSEF_t2 =~ csef02.t2 + a*csef03.t2 
  LST_t1 =~ lskX.t1
  LST_t2 =~ lskX.t2
  EEA_t1 =~ eeaX.t1
  EEA_t2 =~ eeaX.t2
  ENTAL_t1 =~ ental02.t1 + b*ental01.t1  
  ENTAL_t2 =~ ental02.t2+ b*ental01.t2 
  
  # Banded error structure
  #csef01.t1 ~~csef01.t2
  csef02.t1 ~~csef02.t2
  csef03.t1 ~~csef03.t2
  ental01.t1 ~~ental01.t2
  ental02.t1 ~~ental02.t2
  #ental03.t1 ~~ental03.t2

#fixed errors
  eeaX.t1 ~~.201*eeaX.t1
  eeaX.t2 ~~.189*eeaX.t2
  lskX.t1 ~~.192*lskX.t1
  lskX.t2 ~~.23*lskX.t2
'

fit.cfa2 <- sem(cfa2, data = data, estimator="MLR", missing="FIML")

summary(fit.cfa2, fit.measures=TRUE, standardized=TRUE)

