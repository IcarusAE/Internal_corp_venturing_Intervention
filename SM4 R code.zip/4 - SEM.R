library(lavaan)
library(tidyverse)
library(gridExtra)


#<############################################################################>                                                                           ##
#
## SEM  
#                                                                           
#<############################################################################>


#Fuer diesen Zweck benenn ich einige Variablen um

semdata = data

semdata <- semdata %>% 
  rename(lsk_t1 = lskX.t1, 
         lsk_t2 = lskX.t2, 
         alert_t1 = entalX.t1,
         alert_t2 = entalX.t2, 
         CET = treatment)


#Neues Modell (alertness als determinant von  self-efficacy)
medmod <- '
  csefX.t2 ~ csefX.t1 + d*lsk_t2 + e*alert_t2 + i*CET
  alert_t2 ~ alert_t1 +  c*lsk_t2 + b*CET
  lsk_t2 ~ lsk_t1 + a*CET
  eeaX.t2 ~ eeaX.t1 + g*csefX.t2 + h*alert_t2  + f*lsk_t2
  
  tie.cet.lsk.eea := a*f + a*d*g + a*c*h + a*c*e*g
  tie.cet.alt.eea := b*h + b*e*g
  tie.cet.csef.eea := i*g + a*d*g + b*e*g
  te.cet.csef := i + a*d + b*e
  te.cet.eea := a*f + a*d*g + i*g + b*h + b*e*g + a*c*e*g + a*c*h
'
#Bootstrapping
fit.medmod.bs <- sem(medmod, data=semdata, estimator="ML", missing="FIML", fixed.x=TRUE, test="Yuan-Bentler", se="boot")
summary(fit.medmod.bs, standardized=TRUE, modindices=FALSE, fit.measure=TRUE)

swain(276, 9, 13, 15.569, 1168.875)

#Estimates of direct and indirect effects
'Note. CIs can slightly deviate from the paper due to the random bootstrapping'
parameterEstimates(fit.medmod.bs, ci=TRUE, standardized=TRUE) %>% 
  as_tibble() %>% 
  select(lhs, op, rhs, est, ci.lower, ci.upper, std.all, pvalue) %>% 
  filter(op != "~1" & op != "~~") %>% 
  mutate(across(4:8, round, 2)) %>% 
  print(n=30) 

  





