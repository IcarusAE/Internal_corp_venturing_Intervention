#<############################################################################>
#                                                                            
# Required ----
#                                                                            
#<############################################################################>
 
'Note: if not already installed, install them with 
install.packages("packagename")
'

library(tidyverse)
library(janitor) 
library(lavaan)
library(psych)



#<############################################################################>
#                                                                            
# Descriptive stats----
#                                                                            
#<############################################################################>


#descriptives for work experience 
data %>% 
  summarise(mean_exp = mean(job_exp, na.rm = T), sd_exp = sd(job_exp, na.rm=TRUE))


#descriptives age
data %>% 
  summarise(mean_age = mean(age, na.rm = T), sd_age = sd(age, na.rm=TRUE))


# Frequencies treatment and control group
data %>% 
  count(treatment)



#<############################################################################>
#                                                                            
# Reliabilities----
#                                                                            
#<############################################################################>

'In the following alphas will be calculated for the 2-items scales and omega for the 
scales with more than 2 measures as omega (which is to be preferred when possible) 
requires more then 2 items'

#Alertness
data %>% select(ental01.t1,ental02.t1) %>% 
  psych::alpha(.) 

data %>% select(ental01.t2,ental02.t2) %>% 
  psych::alpha(.) 


#Self-efficacy
data %>% select(csef02.t1, csef03.t1) %>% 
  psych::alpha(.) 

data %>% select(csef02.t2, csef03.t2) %>% 
  psych::alpha(.) 

# EEA 
data %>% select(epbhv01.t1,epbhv02.t1,epbhv03.t1,epbhv04.t1,epbhv05.t1,epbhv06.t1,epbhv07.t1,epbhv08.t1) %>% 
  psych::omega(., plot=FALSE) %>% 
  pluck("omega.tot") %>% 
  round(.,2)

data %>% select(epbhv01.t2,epbhv02.t2,epbhv03.t2,epbhv04.t2,epbhv05.t2,epbhv06.t2,epbhv07.t2,epbhv08.t2) %>% 
  psych::omega(., plot=FALSE) %>% 
  pluck("omega.tot") %>% 
  round(.,2)


# Lean startup knowledge  
data %>% select(srp01.t1, srp02.t1, srp03.t1, srp04.t1, srp05.t1) %>%
  psych::omega(., plot=FALSE) %>% 
  pluck("omega.tot") %>% 
  round(.,2)

data %>% select(srp01.t2, srp02.t2, srp03.t2, srp04.t2, srp05.t2) %>%  
  psych::omega(., plot=FALSE) %>% 
  pluck("omega.tot") %>% 
  round(.,2)






#<############################################################################>
#                                                                            
# Table 1: Pre-intervention differences ----
#                                                                            
#<############################################################################>



#> Descriptives: Means und SDs ####
#<############################################################################>

# CET group
cet_table <- data %>% 
  filter(treatment==1) %>% 
  select(age,  job_exp ,tenure, yrs_in_pos, 
         lskX.t1, entalX.t1, csefX.t1, eeaX.t1) %>% 
  psych::describe(.) %>% 
  tibble(.) %>% 
  select(mean, sd) %>% 
  round(.,1) %>% 
  mutate(sd = paste0("(", sd, ")")) %>% 
  unite("CET group", mean, sd, sep=" ", remove=TRUE) 

#Control group
control_table <- data %>% 
  filter(treatment==0) %>% 
  select(age,  job_exp ,tenure, yrs_in_pos, 
         lskX.t1, entalX.t1, csefX.t1, eeaX.t1) %>% 
  psych::describe(.) %>% 
  tibble(.) %>% 
  select(mean, sd) %>% 
  round(.,1) %>% 
  mutate(sd = paste0("(", sd, ")")) %>% 
  unite("Control group", mean, sd, sep=" ", remove=TRUE)  

labels <- tibble(c("Age",  "Job Experience" ,"Tenure", "Yrs in position", "Lean starup knowledge", "Alertness", "Creative self-eff", "EEA"))
cbind(labels, cet_table, control_table)




#> Statistical Tests for comparing CET and control groups ####
#<############################################################################>

#Age
t.test(data$age~ data$treatment)

# Job experience
t.test(data$job_exp ~ data$treatment)

# Tenure
t.test(data$tenure ~ data$treatment)

#Years in Position
t.test(data$yrs_in_pos ~ data$treatment)

# Lean startup knowledge
t.test(data$lskX.t1~ data$treatment)

# Entrepreneurial alertness
t.test(data$entalX.t1~ data$treatment)

# Creative self-efficacy
t.test(data$csefX.t1~ data$treatment)

# EEA
t.test(data$eeaX.t1~ data$treatment)






#<############################################################################>
##                                                                           
## Table 2: Attrition analysis ----
##                                                                           
#<############################################################################>

#> Generation of a attrition indicator 
#<############################################################################>


#Generation of missiness indicator (missingness = 1!)
data <- data %>% 
  mutate(miss_t2 = case_when(is.na(eeaX.t2) & is.na(lskX.t2) & is.na(csefX.t2) ~ 1,
                             !is.na(eeaX.t2)& !is.na(lskX.t2) & !is.na(csefX.t2) ~ 0))  
data$miss_t2<- as.factor(data$miss_t2)


#Number of full participants and dropouts  per group
data %>% 
  group_by(treatment, miss_t2) %>% 
  count() %>% 
  spread(miss_t2, n) %>% 
  rename("present" = "0", "missing" = "1")



#percentage dropouts per treatment group and control group
data %>% 
  tabyl(miss_t2,treatment)%>%
  adorn_percentages("col") %>% 
  adorn_pct_formatting(digits = 2) %>% 
  adorn_ns()



#> Table: Logistic regression predicting missingness in t2
#<############################################################################>
logreg <- glm(miss_t2 ~        
                age + gnd_num + 
                tenure + yrs_in_pos + job_exp +
                eeaX.t1 + csefX.t1 + lskX.t1 + entalX.t1
               , data=data,
              family=binomial(link="logit"))
summary(logreg)

#Odds ratios
round(exp(logreg$coefficients),2)






#<############################################################################>
#                                                                            
# Table 3: Correlation matrix----
#                                                                            
#<############################################################################>

# Create function to print correlation matrix with asterisks
#<############################################################################>

'Note. The following block of code generates a function which purpose is only
to later print a nice looking table with asterisks for signficant correlations.
To do: only run the code til /including the "}" (even if nothing happens now).'

corstarsl <- function(x){ 
  require(Hmisc) 
  x <- as.matrix(x) 
  R <- rcorr(x)$r 
  p <- rcorr(x)$P 
  
  ## define notions for significance levels; spacing is important.
  mystars <- ifelse(p < .01, "** ", ifelse(p < .05, "* ", " "))
  
  ## trunctuate the matrix that holds the correlations to two decimal
  R <- format(round(cbind(rep(-1.11, ncol(x)), R), 2))[,-1] 
  
  ## build a new matrix that includes the correlations with their apropriate 
  stars 
  Rnew <- matrix(paste(R, mystars, sep=""), ncol=ncol(x)) 
  diag(Rnew) <- paste(diag(R), " ", sep="") 
  rownames(Rnew) <- colnames(x) 
  colnames(Rnew) <- paste(colnames(x), "", sep="") 
  
  ## remove upper triangle
  Rnew <- as.matrix(Rnew)
  Rnew[upper.tri(Rnew, diag = TRUE)] <- ""
  Rnew <- as.data.frame(Rnew) 
  
  ## remove last column and return the matrix (which is now a data frame)
  Rnew <- cbind(Rnew[1:length(Rnew)-1])
  return(Rnew) 
}


# Correlation matrix
#<############################################################################>

subData <- data %>% 
   select(treatment, age, gnd_num, tenure, yrs_in_pos, job_exp,
         entalX.t1, csefX.t1, lskX.t1, eeaX.t1,
         entalX.t2, csefX.t2, lskX.t2, eeaX.t2) 



#Correlation matrix
cormat <- subData %>% 
  cor(., use="pair") %>% 
  round(.,2)

#not the subdata are fed in the function generated earlier
(corrtable <- corstarsl(subData) )
write.table(corrtable,file="clipboard",sep="\t",col.names=NA) 


#N and P
rc <- rcorr(as.matrix(subData))
range(rc$n) #Range of N's
round(rc$P,2) #P-value of the correlations







#<############################################################################>
#
# Table 4: Mean Differences between CET group and Control group pre - and post test ----
#
#<############################################################################>



# Lean startup knowledge
#<=============================================================================>

#Longitudinal means
data %>%
  group_by(treatment) %>%
  summarise(mean_lsk.t1 = mean(lskX.t1, na.rm=TRUE) , 
            mean_lsk.t2 = mean(lskX.t2, na.rm=TRUE)) 

#Longitudinal SDs
data %>%
  group_by(treatment) %>%
  summarise(sd_lsk.t1 = sd(lskX.t1, na.rm=TRUE) , 
            sd_lsk.t2 = sd(lskX.t2, na.rm=TRUE)) %>% 
  round(.,2)




# Entrepreneurial alertness
#<=============================================================================>

#Longitudinal means
data %>%
  group_by(treatment) %>%
  summarise(mean_ental.t1 = mean(entalX.t1, na.rm=TRUE) , 
            mean_ental.t2 = mean(entalX.t2, na.rm=TRUE)) 

#Longitudinal SDs
data %>%
  group_by(treatment) %>%
  summarise(sd_ental.t1 = sd(entalX.t1, na.rm=TRUE) , 
            sd_ental.t2 = sd(entalX.t2, na.rm=TRUE)) %>% 
  round(.,2)



# Creative self-efficacy
#<=============================================================================>

#Longitudinal means
data %>%
  group_by(treatment) %>%
  summarise(mean_csef.t1 = mean(csefX.t1, na.rm=TRUE) , 
            mean_csef.t2 = mean(csefX.t2, na.rm=TRUE)) 

#Longitudinal SDs
data %>%
  group_by(treatment) %>%
  summarise(SD_csef.t1 = sd(csefX.t1, na.rm=TRUE) , 
            SD_csef.t2 = sd(csefX.t2, na.rm=TRUE)) %>% 
  round(.,2)





# EEA
#<=============================================================================>

#Longitudinal means
data %>%
  group_by(treatment) %>%
  summarise(mean_eea.t1 = mean(eeaX.t1, na.rm=TRUE) , 
            mean_eea.t2 = mean(eeaX.t2, na.rm=TRUE))

#Longitudinal SDs
data %>%
  group_by(treatment) %>%
  summarise(sd_eea.t1 = sd(eeaX.t1, na.rm=TRUE) , 
            sd_eea.t2 = sd(eeaX.t2, na.rm=TRUE)) %>% 
  round(.,2)


